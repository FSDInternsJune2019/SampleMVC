package com.virtusa.client;

import java.util.Scanner;

import com.virtusa.controller.StudentController;
import com.virtusa.view.StudentView;

public class StudentClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StudentView studentView=new StudentView();
		studentView.mainMenu();

	}

}
